//---------------------------------------------------------------------------

#include <cmath>
#include <vector>
#include <iostream>
#include <string>
#include <stdio.h>
#include "clipper.hpp"

//---------------------------------------------------------------------------

using namespace clipper;
using namespace std;

bool LoadFromFile(char* filename, TPolyPolygon &pp){
  char buffer[10];
  FILE *f = fopen(filename, "r");
  if (f == 0) return false;
  int polyCnt, vertCnt, i, j;
  double X, Y;
  pp.clear();
  if (fscanf(f, "%d", &polyCnt) != 1 || polyCnt == 0) return false;
  pp.resize(polyCnt);
  for (i = 0; i < polyCnt; i++) {
    if (fscanf(f, "%d", &vertCnt) != 1) return false;
    pp[i].resize(vertCnt);
    for (j = 0; j < vertCnt; j++){
      if (fscanf(f, "%lf, %lf", &X, &Y) != 2) return false;
      pp[i][j].X = X; pp[i][j].Y = Y;
      fgets(buffer, 10, f); //gobble any trailing commas
    }
  }
  fclose(f);
  return true;
}
//---------------------------------------------------------------------------

void SaveToConsole(const string name, const TPolyPolygon &pp)
{
  cout << '\n' << name << ":\n"
    << pp.size() << '\n';
  for (unsigned i = 0; i < pp.size(); ++i)
  {
    cout << pp[i].size() << '\n';
    for (unsigned j = 0; j < pp[i].size(); ++j)
      cout << pp[i][j].X << ", " << pp[i][j].Y << ",\n";
  }
  cout << "\n";
}
//---------------------------------------------------------------------------

void SaveToFile(char *filename, TPolyPolygon &pp)
{
  FILE *f = fopen(filename, "w");
  fprintf(f, "%d\n", pp.size());
  for (unsigned i = 0; i < pp.size(); ++i)
  {
    fprintf(f, "%d\n", pp[i].size());
    for (unsigned j = 0; j < pp[i].size(); ++j)
      fprintf(f, "%.4f, %.4f,\n", pp[i][j].X, pp[i][j].Y);
  }
  fclose(f);
}
//---------------------------------------------------------------------------

int main(int argc, char* argv[])
{

  if (argc < 3)
  {
    cout << "\nUSAGE:\n"
      << "clipper.exe subject_file clip_file "
      << "[INTERSECTION | UNION | DIFFERENCE | XOR] "
      << "[EVENODD | NONZERO] [EVENODD | NONZERO]\n";
    cout << "\nINPUT AND OUTPUT FILE FORMAT ([optional] {comments}):\n"
      << "Polygon Count\n"
      << "Vertex Count {first polygon}\n"
      << "X, Y[,] {first vertex}\n"
      << "X, Y[,] {next vertex}\n"
      << "{etc.}\n"
      << "Vertex Count {next polygon, if there is one}\n"
      << "X, Y[,] {first vertex of next polygon}\n"
      << "{etc.}\n\n";
    return 1;
  }

  TPolyPolygon subject, clip;
  if (!LoadFromFile(argv[1], subject))
  {
    cerr << "\nCan't open the file " << argv[1]
      << " or the file format is invalid.\n";
    return 1;
  }
  if (!LoadFromFile(argv[2], clip))
  {
    cerr << "\nCan't open the file " << argv[2]
      << " or the file format is invalid.\n";
    return 1;
  }

  TClipType clipType = ctIntersection;
  const string ClipType[] = {"INTERSECTION", "UNION", "DIFFERENCE", "XOR"};

  if (argc > 3)
  {
    if (stricmp(argv[3], "XOR") == 0) clipType = ctXor;
    else if (stricmp(argv[3], "UNION") == 0) clipType = ctUnion;
    else if (stricmp(argv[3], "DIFFERENCE") == 0) clipType = ctDifference;
    else clipType = ctIntersection;
  }

  TPolyFillType subj_pft = pftNonZero, clip_pft = pftNonZero;
  if (argc == 6)
  {
    if (stricmp(argv[4], "EVENODD") == 0) subj_pft = pftEvenOdd;
    if (stricmp(argv[5], "EVENODD") == 0) clip_pft = pftEvenOdd;
  }

  Clipper c;
  c.AddPolyPolygon(subject, ptSubject);
  c.AddPolyPolygon(clip, ptClip);
  TPolyPolygon solution;
  c.Execute(clipType, solution, subj_pft, clip_pft);

  string s = "Subjects (";
  s += (subj_pft == pftEvenOdd ? "EVENODD)" : "NONZERO)");
  SaveToConsole(s, subject);
  s = "Clips (";
  s += (clip_pft == pftEvenOdd ? "EVENODD)" : "NONZERO)");
  SaveToConsole(s, clip);
  s = "Solution (using " + ClipType[clipType] + ")";
  SaveToConsole(s, solution);
  return 0;
}
//---------------------------------------------------------------------------
